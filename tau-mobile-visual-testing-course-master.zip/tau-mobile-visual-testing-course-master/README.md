# Visual Testing for Mobile Apps (Test Automation U Course)

This is the sample code project for the course on mobile visual testing from Test Automation U, by Jonathan Lipps.

You can find the course [here](https://testautomationu.applitools.com/instructors/jonathan_lipps.html).

All of the interesting code in this repo is [here](https://github.com/cloudgrey-io/tau-mobile-visual-testing-course/tree/master/src/test/java).
